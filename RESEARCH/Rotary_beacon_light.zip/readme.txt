Attribution
-----------
If you use the dataset in scientific work, please cite:

ADFI, "Real-World Dataset for Anomaly Detection", AI Robotics LTD., 2022, https://adfi.jp


License
-------
Copyright 2022 AI Robotics LTD.

This work is licensed under a Creative Commons 
Attribution-NonCommercial-ShareAlike 4.0 International License.

You should have received a copy of the license along with this work.
If not, see <http://creativecommons.org/licenses/by-nc-sa/4.0/>.

For using the data in a way that falls under the commercial use clause
of the license, please contact us.


Contact
-------
If you have any questions or comments about the dataset, feel free to
contact us via: biz-team@airobotics.jp, https://adfi.jp